package com.rewardsystem.honor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HonorApplicationTests {

    @Test
    void contextLoads() {
    }

}
